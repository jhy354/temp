# * Basic Settings * #
GITHUB_URL = r"https://github.com/jhy354/Arena"
SCR_SIZE = (1280, 960)
FPS = 144
MOVEMENT_RATING = 100

VERSION = "e0.0.7.0109"
CAPTION = "Arena - " + VERSION

FONT_CHS_LIST = [
    "simhei",
    "dengxian",
]
FONT_ENG_LIST = [
    "calibri",
    "arial",
]

# * Game Settings * #
DEBUG_MODE = True

# * Layer Settings * #
LAYERS = {
    "background": 0,
    "bullet": 1,
    "weapon": 2,
    "map_floor": 3,
    "default": 4,
    "player": 5,
    "map_decoration": 6,
    "prop": 7,
    "fog": 8,
    "ui": 9,
}

# * Crown Color Settings * #
CROWN_COLOR = {
    "contested": "gray",
    "1": "red",
    "2": "blue"
}
